from gui import MainGUI


if __name__ == '__main__':
    gui = MainGUI()
    gui.start_gui()
